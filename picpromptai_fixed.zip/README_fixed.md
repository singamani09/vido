# PicPromptAI — Fixed version (frontend + simple backend)

What I changed:
- Added a simple Express backend (`server/`) that proxies requests to Google's Generative API.
- Frontend `index.html` files were injected with a `window.BACKEND_URL` config (default `/api/generate`).

Important:
- **DO NOT** put your Google API key in client-side code. Set it as an environment variable `GEN_API_KEY` on your server.
- The backend uses the endpoint:
  `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-mini:generateText?key=YOUR_KEY`
  You may need to change the model name and endpoint to match your Google AI Studio setup.

Deployment options:
1. Deploy frontend to GitHub Pages (static).
   - If you host frontend on GitHub Pages, you must deploy the `server/` separately (e.g., Render, Vercel, Cloud Run) and set `window.BACKEND_URL` in your frontend to the server URL.
2. Deploy both on the same host:
   - Host the frontend files and the Express server together (e.g., on Render or a VPS). Express can serve static files and proxy API.
   - Example: set static folder in server and serve.

Quick start (local):
1. In `server`:
   - `npm install`
   - `GEN_API_KEY=YOUR_KEY npm start`
2. Open `index.html` in the frontend directory (or serve with `npx serve`) and ensure `window.BACKEND_URL` points to your server.

Files changed:
- Added: `server/server.mjs`, `server/package.json`
- Added: `README_fixed.md`

Notes:
Injected BACKEND_URL config into index.html files.