import express from 'express';
import fetch from 'node-fetch';
import cors from 'cors';
const app = express();
app.use(cors());
app.use(express.json());

const API_KEY = process.env.GEN_API_KEY; // set this in your hosting environment

app.post('/api/generate', async (req, res) => {
  if (!API_KEY) return res.status(500).json({error: 'Server misconfigured: GEN_API_KEY not set'});
  try {
    const body = req.body;
    // Replace with the appropriate Gemini endpoint if different
    const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-mini:generateText?key=${API_KEY}`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(body)
    });
    const data = await resp.json();
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({error: String(err)});
  }
});

const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log('Server listening on', port));