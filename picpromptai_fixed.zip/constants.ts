
import { ArtStyle, Language } from './types';

export const ART_STYLES: ArtStyle[] = Object.values(ArtStyle);
export const LANGUAGES: Language[] = Object.values(Language);
